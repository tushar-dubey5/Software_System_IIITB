#ifndef LOGOUT_H
#define LOGOUT_H

void logout(int user_id, int socket);

#endif